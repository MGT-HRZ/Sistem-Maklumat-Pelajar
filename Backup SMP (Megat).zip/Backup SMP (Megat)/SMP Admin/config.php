<?php

	$dbServername = "localhost";
	$dbUsername = "root";
	$dbPassword = "";
	$dbName = "crud";

	$connect = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);

?>