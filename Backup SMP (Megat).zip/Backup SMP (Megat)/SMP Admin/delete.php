<?php
	
	include_once "config.php";

	$id = $_GET['id'];
	$sql = "DELETE FROM users WHERE id = '$id'";
	$result = mysqli_query($connect, $sql);

	if ($result) {
		header("Location: view database.php");
	}

	else {
		echo "Fail to Delete !!!";
	}

?>